import {NgModule} from '@angular/core';
import {IonicModule} from 'ionic-angular';
import {LoginPage} from './login';
import {FindPasswordPage} from './find-password/find-password';
import {RegisterPage} from './register/register';
import {ChecknumPage} from "./check/check";
import {newpasswordPage} from "./newpassword/newpassword";
import {SetPasswordPage} from "./set-password/set-password";

@NgModule({
  imports: [IonicModule],
  declarations: [LoginPage, FindPasswordPage, RegisterPage,ChecknumPage,newpasswordPage,SetPasswordPage],
  entryComponents: [LoginPage, FindPasswordPage, RegisterPage,ChecknumPage,newpasswordPage,SetPasswordPage],
  providers: [],
  exports: [IonicModule]
})
export class LoginModule {
}
