"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var LoginService_1 = require("../LoginService");
var set_password_1 = require("../set-password/set-password");
var ChecknumPage = (function () {
    function ChecknumPage(navCtrl, viewCtrl, modalCtrl, formBuilder, alertCtrl, globalData, loginService) {
        this.navCtrl = navCtrl;
        this.viewCtrl = viewCtrl;
        this.modalCtrl = modalCtrl;
        this.formBuilder = formBuilder;
        this.alertCtrl = alertCtrl;
        this.globalData = globalData;
        this.loginService = loginService;
        this.mes = { "tel": "188", "verificationcode": "0" };
        this.checkForm = this.formBuilder.group({
            checknum: [, [forms_1.Validators.required, forms_1.Validators.pattern('[0-9]{6}')]],
        });
        this.btnText = "119秒后重新获取";
        this.tel = this.globalData.userPhone;
        this.buttonstate = true;
        this.sec = 119;
        var _self = this;
        var time = setInterval(function () {
            _self.sec--;
            if (_self.sec <= 0) {
                _self.btnText = "获取验证码";
                _self.buttonstate = false;
                window.clearInterval(time);
            }
            else {
                _self.btnText = _self.sec.toString() + "秒后重新获取";
                _self.buttonstate = true;
            }
        }, 1000);
    }
    ;
    ChecknumPage.prototype.setTime = function () {
        var second = 120;
        //this.btnText = second.toString();
        var _self = this;
        var time = setInterval(function () {
            second--;
            if (second <= 0) {
                _self.btnText = "获取验证码";
                _self.buttonstate = false;
                window.clearInterval(time);
            }
            else {
                _self.btnText = second.toString() + "秒后重新获取";
                _self.buttonstate = true;
            }
        }, 1000);
    };
    ChecknumPage.prototype.confirm = function () {
        var _this = this;
        this.loginService.sendVerificationCode(this.globalData.userPhone, this.checkForm.value.checknum).subscribe(function (res) {
            if (res.result == "yes") {
                var modal = _this.modalCtrl.create(set_password_1.SetPasswordPage);
                modal.present();
            }
            else if (res.result == "no") {
                _this.alertCtrl.create({
                    title: '验证码错误',
                    subTitle: '请重新输入正确的验证码！',
                    buttons: ['确定']
                }).present();
            }
            else {
                _this.alertCtrl.create({
                    title: '数据获取失败',
                    subTitle: '请重新获取验证码！',
                    buttons: ['确定']
                }).present();
            }
        });
    };
    ChecknumPage.prototype.dismiss = function () {
        this.viewCtrl.dismiss();
    };
    return ChecknumPage;
}());
ChecknumPage = __decorate([
    core_1.Component({
        selector: 'page-checknum',
        templateUrl: 'check.html',
        providers: [LoginService_1.LoginService]
    })
], ChecknumPage);
exports.ChecknumPage = ChecknumPage;
