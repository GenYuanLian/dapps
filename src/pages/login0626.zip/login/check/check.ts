import {Component} from '@angular/core';
import {NavController, ViewController,AlertController,ModalController} from 'ionic-angular';
import {FormBuilder, Validators} from '@angular/forms';
import {LoginService} from '../LoginService';
import {UserInfo} from "../../../model/UserInfo";
import {GlobalData} from "../../../providers/GlobalData";
import {SetPasswordPage} from "../set-password/set-password";

@Component({
  selector: 'page-checknum',
  templateUrl: 'check.html',
  providers: [LoginService]
})
export class ChecknumPage {
  userInfo:UserInfo;
  checkForm: any;
  tel:string;
  btnText:string;
  buttonstate:boolean;
  sec:number;
  mes={"tel":"188","verificationcode":"0"};

  constructor(private navCtrl: NavController,
              private viewCtrl: ViewController,
              private modalCtrl: ModalController,
              private formBuilder: FormBuilder,
              private alertCtrl: AlertController,
              private globalData: GlobalData,
              private loginService: LoginService) {

    this.checkForm = this.formBuilder.group({
      checknum: [, [Validators.required, Validators.pattern('[0-9]{6}')]],
    })
    this.btnText = "119秒后重新获取"
    this.tel=this.globalData.userPhone;
    this.buttonstate=true;
    this.sec=119;
    var _self=this;
    var time=setInterval(function () {
      _self.sec--;
      if(_self.sec<=0){
        _self.btnText="获取验证码";
        _self.buttonstate=false;
        window.clearInterval(time);
      }
      else{
        _self.btnText=_self.sec.toString()+"秒后重新获取";
        _self.buttonstate=true;

      }
    },1000);
  };
  setTime() {
    var second = 120;
    //this.btnText = second.toString();
    var _self=this;
    var time=setInterval(function () {
      second--;
      if(second<=0){
        _self.btnText="获取验证码";
        _self.buttonstate=false;
        window.clearInterval(time);
      }
      else{
        _self.btnText=second.toString()+"秒后重新获取";
        _self.buttonstate=true;

      }
    },1000);
  }
  confirm() {
    this.loginService.sendVerificationCode(this.globalData.userPhone,this.checkForm.value.checknum).subscribe(res => {
      if(res.result=="yes"){
        let modal = this.modalCtrl.create(SetPasswordPage);
        modal.present();
      }
      else if(res.result=="no"){
        this.alertCtrl.create({
          title: '验证码错误',
          subTitle: '请重新输入正确的验证码！',
          buttons: ['确定']
        }).present();
      }
      else {
        this.alertCtrl.create({
          title: '数据获取失败',
          subTitle: '请重新获取验证码！',
          buttons: ['确定']
        }).present();
      }
    });


  }
  dismiss() {
    this.viewCtrl.dismiss();
  }

}

