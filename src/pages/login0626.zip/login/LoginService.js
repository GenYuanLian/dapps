"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var rxjs_1 = require("rxjs");
var LoginService = (function () {
    function LoginService(httpService) {
        this.httpService = httpService;
    }
    LoginService.prototype.isTelRegister = function (tel) {
        return this.httpService.get('http://10.103.240.171:8080/user/register/telCheck?tel=' + tel).map(function (res) { return res.json(); });
    };
    LoginService.prototype.sendVerificationCode = function (tel, verificationcode) {
        return this.httpService.get('http://10.103.240.171:8080/user/register/verificationcodeCheck?tel=' + tel + "&verificationcode=" + verificationcode).map(function (res) { return res.json(); });
    };
    LoginService.prototype.sendPassword = function (tel, pwd) {
        return this.httpService.get('http://10.103.240.171:8080/user/register/passwordStore?tel=' + tel + "&pwd=" + pwd).map(function (res) { return res.json(); });
    };
    LoginService.prototype.getObj = function (name) {
        return this.httpService.get('http://127.0.0.1:3000/users/getUserByName/' + name).map(function (res) { return res.json(); });
    };
    LoginService.prototype.getIsRegister = function (user) {
        return this.httpService.post('http://127.0.0.1:3000/users/createUser').map(function (res) { return res.json(); });
    };
    LoginService.prototype.register = function (user) {
        var _this = this;
        return rxjs_1.Observable.create(function (observer) {
            _this.getIsRegister(user).subscribe(function (res) {
                return res['success'];
            });
        });
    };
    LoginService.prototype.login = function (tel, psw) {
        return this.httpService.get('http://10.103.240.255:8080/user/login?tel=' + tel + "&password=" + psw).map(function (res) { return res.json(); });
    };
    return LoginService;
}());
LoginService = __decorate([
    core_1.Injectable()
], LoginService);
exports.LoginService = LoginService;
