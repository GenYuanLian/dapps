"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var login_1 = require("../login");
var LoginService_1 = require("../LoginService");
var SetPasswordPage = (function () {
    function SetPasswordPage(navCtrl, viewCtrl, formBuilder, modalCtrl, globalData, alertCtrl, loginService) {
        this.navCtrl = navCtrl;
        this.viewCtrl = viewCtrl;
        this.formBuilder = formBuilder;
        this.modalCtrl = modalCtrl;
        this.globalData = globalData;
        this.alertCtrl = alertCtrl;
        this.loginService = loginService;
        this.setPasswordForm = this.formBuilder.group({
            password1: [, [forms_1.Validators.required, forms_1.Validators.minLength(6), forms_1.Validators.maxLength(20)]],
            password2: [, [forms_1.Validators.required, forms_1.Validators.minLength(6), forms_1.Validators.maxLength(20)]],
        });
        this.tel = this.globalData.userId;
        this.pwdshow = "弱";
        this.pswValid = true;
    }
    ;
    SetPasswordPage.prototype.onKey = function (pwd) {
        console.log(pwd);
        var m = 0;
        var Modes = 0;
        for (var i = 0; i < pwd.length; i++) {
            var charType = 0;
            var t = pwd.charCodeAt(i);
            if (t >= 48 && t <= 57) {
                charType = 1;
            }
            else if (t >= 65 && t <= 90) {
                charType = 2;
            }
            else if (t >= 97 && t <= 122) {
                charType = 4;
            }
            else {
                charType = 4;
            }
            Modes |= charType;
        }
        for (i = 0; i < 4; i++) {
            if (Modes & 1) {
                m++;
            }
            Modes >>>= 1;
        }
        switch (m) {
            case 1:
                this.pwdshow = "弱";
                console.log("弱");
                break;
            case 2:
                this.pwdshow = "中";
                console.log("中");
                break;
            case 3:
                this.pwdshow = "强";
                console.log("强");
                break;
            default:
                this.pwdshow = "弱";
                console.log("弱");
                break;
        }
    };
    SetPasswordPage.prototype.confirm = function () {
        var _this = this;
        var _self = this;
        console.log(this.setPasswordForm.value.password1);
        console.log(this.setPasswordForm.value.password2);
        if (this.setPasswordForm.value.password1 != this.setPasswordForm.value.password2) {
            console.log('密码不一致');
            _self.pswValid = false;
        }
        else {
            this.loginService.sendPassword(this.globalData.userPhone, this.setPasswordForm.value.password1).subscribe(function (res) {
                if (res.result == "yes") {
                    var modal = _this.modalCtrl.create(login_1.LoginPage);
                    modal.present();
                }
                else {
                    _this.alertCtrl.create({
                        title: '密码设置失败',
                        subTitle: '请稍后重新设置！',
                        buttons: ['确定']
                    }).present();
                }
            });
        }
    };
    SetPasswordPage.prototype.dismiss = function () {
        this.viewCtrl.dismiss();
    };
    return SetPasswordPage;
}());
SetPasswordPage = __decorate([
    core_1.Component({
        selector: 'page-set-password',
        templateUrl: 'set-password.html',
        providers: [LoginService_1.LoginService]
    })
], SetPasswordPage);
exports.SetPasswordPage = SetPasswordPage;
