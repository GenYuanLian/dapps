import {Component} from '@angular/core';
import {NavController, ViewController,AlertController} from 'ionic-angular';
import {FormBuilder, Validators} from '@angular/forms';
import {LoginPage} from '../login';
import {LoginService} from '../LoginService';
import {UserInfo} from "../../../model/UserInfo";

@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
  providers: [LoginService]
})
export class RegisterPage {
  userInfo:{
    phone:"",
    email:"",
    password:""
  };
  registerForm: any;

  constructor(private navCtrl: NavController,
              private viewCtrl: ViewController,
              private formBuilder: FormBuilder,
              private alertCtrl: AlertController,
              private loginService: LoginService) {
    this.registerForm = this.formBuilder.group({
    /*  verificationCode: [, [Validators.required, Validators.minLength(6), Validators.pattern('1[0-9]{6}')]],*/
      phone: [, [Validators.required, Validators.pattern('1[0-9]{10}')]],
      email: [, [Validators.required, Validators.pattern('[(\u4e00-\u9fa5)0-9a-zA-Z\_\s@]+')]],
      password: [, [Validators.required]]
    })
  };
  confirm(registerUser) {
    this.loginService.register(registerUser.phone,registerUser.email,registerUser.password).subscribe(res =>{
      if(!res['success']){
        this.alertCtrl.create({
          title: '注册失败',
          subTitle: res['msg'],
          buttons: ['OK']
        }).present();
      }else {
        this.navCtrl.push(LoginPage,{
          phone: registerUser.phone,
          password: registerUser.password
        });
      }
      /*if(res){//注册成功
        console.log("注册成功");
        this.navCtrl.setRoot(LoginPage);
      }else{
        this.alertCtrl.create({
          title: '注册失败',
          subTitle: '系统故障，稍后再试',
          buttons: ['OK']
        }).present();
      }*/
    })
  }
  dismiss() {
    this.viewCtrl.dismiss();
  }
}
