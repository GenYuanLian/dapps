"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var login_1 = require("../login");
var LoginService_1 = require("../LoginService");
var RegisterPage = (function () {
    function RegisterPage(navCtrl, viewCtrl, formBuilder, alertCtrl, loginService) {
        this.navCtrl = navCtrl;
        this.viewCtrl = viewCtrl;
        this.formBuilder = formBuilder;
        this.alertCtrl = alertCtrl;
        this.loginService = loginService;
        this.registerForm = this.formBuilder.group({
            /*  verificationCode: [, [Validators.required, Validators.minLength(6), Validators.pattern('1[0-9]{6}')]],*/
            phone: [, [forms_1.Validators.required, forms_1.Validators.pattern('1[0-9]{10}')]],
            email: [, [forms_1.Validators.required, forms_1.Validators.pattern('[(\u4e00-\u9fa5)0-9a-zA-Z\_\s@]+')]],
            password: [, [forms_1.Validators.required]]
        });
    }
    ;
    RegisterPage.prototype.confirm = function () {
        var _this = this;
        // this.navCtrl.setRoot(LoginPage)
        this.userInfo.username = this.registerForm.value.username;
        this.userInfo.email = this.registerForm.value.email;
        this.userInfo.password = this.registerForm.value.password;
        this.loginService.register(this.userInfo).subscribe(function (res) {
            alert(res);
            if (res) {
                console.log("注册成功");
                _this.navCtrl.setRoot(login_1.LoginPage);
            }
            else {
                _this.alertCtrl.create({
                    title: '注册失败',
                    subTitle: '系统故障，稍后再试',
                    buttons: ['OK']
                }).present();
            }
        });
    };
    RegisterPage.prototype.dismiss = function () {
        this.viewCtrl.dismiss();
    };
    return RegisterPage;
}());
RegisterPage = __decorate([
    core_1.Component({
        selector: 'page-register',
        templateUrl: 'register.html',
        providers: [LoginService_1.LoginService]
    })
], RegisterPage);
exports.RegisterPage = RegisterPage;
