import {Component} from '@angular/core';
import {ModalController, ViewController, Platform, AlertController,NavController,NavParams} from 'ionic-angular';
import {Storage} from '@ionic/storage';
import {FormBuilder, Validators} from '@angular/forms';
import {LoginService} from './LoginService';
import {FindPasswordPage} from './find-password/find-password';
import {RegisterPage} from './register/register';
import {UserInfo} from "../../model/UserInfo";
import {GlobalData} from "../../providers/GlobalData";
import {TabsPage} from "../tabs/tabs";

@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
  providers: [LoginService]
})
export class LoginPage {
  userInfo: UserInfo;
  submitted: boolean = false;
  canLeave: boolean = false;
  loginForm: any;
  constructor(private viewCtrl: ViewController,
              private formBuilder: FormBuilder,
              private storage: Storage,
              private modalCtrl: ModalController,
              private platform: Platform,
              private alertCtrl: AlertController,
              private globalData: GlobalData,
              private navCtrl: NavController,
              private navParams: NavParams,
              private loginService: LoginService) {
    if(navParams.get('phone')){
      this.loginForm = this.formBuilder.group({
        username: [navParams.get('phone'), [Validators.required, Validators.minLength(11)]],// 第一个参数是默认值
        password: [navParams.get('password'), [Validators.required, Validators.minLength(6)]]
      });
    }else {
      this.loginForm = this.formBuilder.group({
        username: ['', [Validators.required, Validators.minLength(11)]],// 第一个参数是默认值
        password: ['', [Validators.required, Validators.minLength(6)]]
      });
    }
  }
  ionViewWillEnter() {
    this.storage.get('UserInfo').then(userInfo => {
      this.userInfo = userInfo || null;
    });
  }
 /* ionViewCanLeave(): boolean {
    let bool = !!this.userInfo;
    if (this.canLeave || bool) {
      return true;
    } else {
      this.alertCtrl.create({
        title: '确认退出软件？',
        buttons: [{text: '取消'},
          {
            text: '确定',
            handler: () => {
              this.platform.exitApp();
            }
          }
        ]
      }).present();
      return false;
    }
  }*/
  login(user) {
    this.loginService.login(this.loginForm.value.username,this.loginForm.value.password).subscribe(res => {
        if(res.result!="no"){
          this.globalData.username=this.loginForm.value.username;
          this.globalData.userPassword=this.loginForm.value.password;
          this.navCtrl.setRoot(TabsPage);
        }else {
          this.alertCtrl.create({
            title: '登录失败',
            subTitle: '用户名或密码错误,请重新输入',
            buttons: ['OK']
          }).present();
        }
      });
  }
  toRegister() {
    this.navCtrl.push(RegisterPage);
  }
  findPassword() {
    this.canLeave = true;
    let modal = this.modalCtrl.create(FindPasswordPage);
    modal.present();
    this.canLeave = false
  }
}
