"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var LoginService_1 = require("./LoginService");
var find_password_1 = require("./find-password/find-password");
var register_1 = require("./register/register");
var tabs_1 = require("../tabs/tabs");
var LoginPage = (function () {
    function LoginPage(viewCtrl, formBuilder, storage, modalCtrl, platform, alertCtrl, globalData, navCtrl, loginService) {
        this.viewCtrl = viewCtrl;
        this.formBuilder = formBuilder;
        this.storage = storage;
        this.modalCtrl = modalCtrl;
        this.platform = platform;
        this.alertCtrl = alertCtrl;
        this.globalData = globalData;
        this.navCtrl = navCtrl;
        this.loginService = loginService;
        this.submitted = false;
        this.canLeave = false;
        this.loginForm = this.formBuilder.group({
            username: ['', [forms_1.Validators.required, forms_1.Validators.minLength(11)]],
            password: ['', [forms_1.Validators.required, forms_1.Validators.minLength(6)]]
        });
    }
    LoginPage.prototype.ionViewWillEnter = function () {
        var _this = this;
        this.storage.get('UserInfo').then(function (userInfo) {
            _this.userInfo = userInfo || null;
        });
    };
    LoginPage.prototype.ionViewCanLeave = function () {
        var _this = this;
        var bool = !!this.userInfo;
        if (this.canLeave || bool) {
            return true;
        }
        else {
            this.alertCtrl.create({
                title: '确认退出软件？',
                buttons: [{ text: '取消' },
                    {
                        text: '确定',
                        handler: function () {
                            _this.platform.exitApp();
                        }
                    }
                ]
            }).present();
            return false;
        }
    };
    LoginPage.prototype.login = function () {
        var _this = this;
        this.loginService.login(this.loginForm.value.username, this.loginForm.value.password).subscribe(function (res) {
            if (res.result == "no") {
                _this.globalData.userPhone = _this.loginForm.value.username;
                _this.globalData.userPassword = _this.loginForm.value.password;
                _this.navCtrl.setRoot(tabs_1.TabsPage);
            }
            else {
                _this.alertCtrl.create({
                    title: '登录失败',
                    subTitle: '用户名或密码错误,请重新输入',
                    buttons: ['OK']
                }).present();
            }
        });
    };
    LoginPage.prototype.toRegister = function () {
        this.canLeave = true;
        var modal = this.modalCtrl.create(register_1.RegisterPage);
        modal.present();
        this.canLeave = false;
    };
    LoginPage.prototype.findPassword = function () {
        this.canLeave = true;
        var modal = this.modalCtrl.create(find_password_1.FindPasswordPage);
        modal.present();
        this.canLeave = false;
    };
    return LoginPage;
}());
LoginPage = __decorate([
    core_1.Component({
        selector: 'page-login',
        templateUrl: 'login.html',
        providers: [LoginService_1.LoginService]
    })
], LoginPage);
exports.LoginPage = LoginPage;
