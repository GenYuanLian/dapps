"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var newpassword_1 = require("../newpassword/newpassword");
var LoginService_1 = require("../LoginService");
var FindPasswordPage = (function () {
    function FindPasswordPage(navCtrl, viewCtrl, modalCtrl, alertCtrl, loginService, globalData, formBuilder) {
        this.navCtrl = navCtrl;
        this.viewCtrl = viewCtrl;
        this.modalCtrl = modalCtrl;
        this.alertCtrl = alertCtrl;
        this.loginService = loginService;
        this.globalData = globalData;
        this.formBuilder = formBuilder;
        this.findPasswordForm = this.formBuilder.group({
            phone: [, [forms_1.Validators.required, forms_1.Validators.minLength(11), forms_1.Validators.pattern('1[0-9]{10}')]],
            verificationCode: [, [forms_1.Validators.required, forms_1.Validators.minLength(6), forms_1.Validators.pattern('[0-9]{6}')]],
            newPassword: [, [forms_1.Validators.required, forms_1.Validators.minLength(6)]]
        });
        this.buttonstate = false;
        this.btnText = "获取验证码";
    }
    ;
    FindPasswordPage.prototype.confirm = function () {
        var _this = this;
        this.loginService.sendVerificationCode(this.globalData.userPhone, this.findPasswordForm.value.verificationCode).subscribe(function (res) {
            if (res.result == "yes") {
                var modal = _this.modalCtrl.create(newpassword_1.newpasswordPage);
                modal.present();
            }
            else if (res.result == "no") {
                _this.alertCtrl.create({
                    title: '验证码错误',
                    subTitle: '请重新输入正确的验证码！',
                    buttons: ['确定']
                }).present();
            }
            else {
                _this.alertCtrl.create({
                    title: '数据获取失败',
                    subTitle: '请重新获取验证码！',
                    buttons: ['确定']
                }).present();
            }
        });
    };
    FindPasswordPage.prototype.dismiss = function () {
        this.viewCtrl.dismiss();
    };
    FindPasswordPage.prototype.settime = function () {
        var _this = this;
        this.loginService.isTelRegister(this.findPasswordForm.value.phone).subscribe(function (res) {
            console.log(res);
            if (res.result == "yes") {
                _this.globalData.userPhone = _this.findPasswordForm.value.phone;
                var second = 120;
                var _self = _this;
                var time = setInterval(function () {
                    second--;
                    if (second <= 0) {
                        _self.btnText = "获取验证码";
                        _self.buttonstate = false;
                        window.clearInterval(time);
                    }
                    else {
                        _self.btnText = second.toString() + "秒后重新获取";
                        _self.buttonstate = true;
                    }
                }, 1000);
            }
            else {
                _this.alertCtrl.create({
                    title: '手机未注册',
                    subTitle: '请先注册该手机号！',
                    buttons: ['确定']
                }).present();
            }
        });
    };
    return FindPasswordPage;
}());
FindPasswordPage = __decorate([
    core_1.Component({
        selector: 'page-find-password',
        templateUrl: 'find-password.html',
        providers: [LoginService_1.LoginService]
    })
], FindPasswordPage);
exports.FindPasswordPage = FindPasswordPage;
