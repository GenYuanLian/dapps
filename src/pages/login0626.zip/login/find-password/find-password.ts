import {Component} from '@angular/core';
import {NavController, ViewController,AlertController,ModalController} from 'ionic-angular';
import {FormBuilder, Validators} from '@angular/forms';
import {newpasswordPage} from '../newpassword/newpassword';
import {LoginService} from '../LoginService';
import {GlobalData} from "../../../providers/GlobalData";
import {verObject} from "../../../model/verObject";
import {telCheck} from "../../../model/telCheck";

@Component({
  selector: 'page-find-password',
  templateUrl: 'find-password.html',
  providers: [LoginService]
})
export class FindPasswordPage {
  findPasswordForm: any;
  btnText:string;
  buttonstate:boolean;
  constructor(private navCtrl: NavController,
              private viewCtrl: ViewController,
              private modalCtrl: ModalController,
              private alertCtrl: AlertController,
              private loginService: LoginService,
              private globalData: GlobalData,
              private formBuilder: FormBuilder) {
    this.findPasswordForm = this.formBuilder.group({
      phone: [, [Validators.required, Validators.minLength(11), Validators.pattern('1[0-9]{10}')]],
      verificationCode: [, [Validators.required, Validators.minLength(6), Validators.pattern('[0-9]{6}')]],
      newPassword: [, [Validators.required, Validators.minLength(6)]]
    });
    this.buttonstate=false;
    this.btnText="获取验证码"
  };

  confirm() {
    this.loginService.sendVerificationCode(this.globalData.userPhone,this.findPasswordForm.value.verificationCode).subscribe(res => {
      if(res.result=="yes"){
        let modal = this.modalCtrl.create(newpasswordPage);
        modal.present();
      }
      else if(res.result=="no"){
        this.alertCtrl.create({
          title: '验证码错误',
          subTitle: '请重新输入正确的验证码！',
          buttons: ['确定']
        }).present();
      }
      else {
        this.alertCtrl.create({
          title: '数据获取失败',
          subTitle: '请重新获取验证码！',
          buttons: ['确定']
        }).present();
      }
    });
  }

  dismiss() {
    this.viewCtrl.dismiss();
  }
  settime(){
    this.loginService.isTelRegister(this.findPasswordForm.value.phone).subscribe(res =>{
      console.log(res);
      if(res.result=="yes"){
        this.globalData.userPhone=this.findPasswordForm.value.phone;
        var second = 120;
        var _self=this;
        var time=setInterval(function () {
          second--;
          if(second<=0){
            _self.btnText="获取验证码";
            _self.buttonstate=false;
            window.clearInterval(time);
          }
          else{
            _self.btnText=second.toString()+"秒后重新获取";
            _self.buttonstate=true;
          }
        },1000);
      }
      else{
        this.alertCtrl.create({
          title: '手机未注册',
          subTitle: '请先注册该手机号！',
          buttons: ['确定']
        }).present();

      }
    });


 }
}
