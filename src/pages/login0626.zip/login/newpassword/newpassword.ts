import {Component} from '@angular/core';
import {NavController, ViewController,AlertController,ModalController} from 'ionic-angular';
import {FormBuilder, Validators} from '@angular/forms';
import {LoginService} from '../LoginService';
import {GlobalData} from "../../../providers/GlobalData";
import {MinePage} from '../../mine/mine';
import {LoginPage} from '../login';

@Component({
  selector: 'page-newpassword',
  templateUrl: 'newpassword.html',
  providers: [LoginService]
})
export class newpasswordPage {
  newpasswordForm: any;
  pswValid:boolean;

  constructor(private navCtrl: NavController,
              private viewCtrl: ViewController,
              private modalCtrl: ModalController,
              private formBuilder: FormBuilder,
              private alertCtrl: AlertController,
              private globalData: GlobalData,
              private loginService: LoginService) {
    this.newpasswordForm = this.formBuilder.group({
      psw: [, [Validators.required,Validators.minLength(6),Validators.maxLength(20)]],
      psw2: [, [Validators.required, Validators.pattern('1[0-9]{10}')]],
    })
    this.pswValid=true;
  };
  confirm() {
    var _self=this;
    if(this.newpasswordForm.value.psw!=this.newpasswordForm.value.psw2){
      console.log('密码不一致');
      _self.pswValid=false;
    }
    else {
      this.loginService.sendPassword(this.globalData.userPhone,this.newpasswordForm.value.psw).subscribe(res => {
        if(res.result=="yes"){
          let modal = this.modalCtrl.create(LoginPage);
          modal.present();
        }
        else {
          this.alertCtrl.create({
            title: '密码设置失败',
            subTitle: '请稍后重新设置！',
            buttons: ['确定']
          }).present();
        }
      });
    }
  }
  dismiss() {
    this.viewCtrl.dismiss();
  }

}
