import {Component} from '@angular/core';
import {NavController, ViewController,AlertController,ModalController} from 'ionic-angular';
import {FormBuilder, Validators} from '@angular/forms';
import {LoginPage} from '../login';
import {LoginService} from '../LoginService';
import {UserInfo} from "../../../model/UserInfo";
import {ChecknumPage} from "../check/check";
import {GlobalData} from "../../../providers/GlobalData";

@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
  providers: [LoginService]
})
export class RegisterPage {
  userInfo:UserInfo;
  registerForm: any;
  constructor(private navCtrl: NavController,
              private viewCtrl: ViewController,
              private modalCtrl: ModalController,
              private formBuilder: FormBuilder,
              private alertCtrl: AlertController,
              private globalData: GlobalData,
              private loginService: LoginService) {
    this.registerForm = this.formBuilder.group({
      phone: [, [Validators.required, Validators.pattern('1[0-9]{10}')]],
    })
  };

  confirm() {
    this.loginService.isTelRegister(this.registerForm.value.phone).subscribe(res =>{
      console.log(res+"111");
      if(res.result=="no"){
        this.globalData.userPhone=this.registerForm.value.phone;
        let modal = this.modalCtrl.create(ChecknumPage);
        modal.present();
      } else{
        let confirm = this.alertCtrl.create({
          title: '温馨提示',
          message: '该手机号已注册，是否直接登录?',
          buttons: [
            {
              text: '拒绝',
            },
            {
              text: '同意',
              handler: () => {
                console.log('Agree clicked');
                let modal = this.modalCtrl.create(LoginPage);
                modal.present();
              }
            }
          ]
        });
        confirm.present();

      }
    });
  }
  dismiss() {
    this.viewCtrl.dismiss();
  }
}
