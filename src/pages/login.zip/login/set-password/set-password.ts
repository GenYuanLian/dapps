import {Component} from '@angular/core';
import {NavController, ViewController,ModalController,AlertController} from 'ionic-angular';
import {FormBuilder, Validators} from '@angular/forms';
import {LoginPage} from '../login';
import {LoginService} from '../LoginService';
import {UserInfo} from "../../../model/UserInfo";
import {GlobalData} from "../../../providers/GlobalData";


@Component({
  selector: 'page-set-password',
  templateUrl: 'set-password.html',
  providers: [LoginService]
})
export class SetPasswordPage {
  userInfo:UserInfo;
  setPasswordForm: any;
  password:string;
  tel:string ;
  pwdshow:string;
  pswValid:boolean;
  constructor(private navCtrl: NavController,
              private viewCtrl: ViewController,
              private formBuilder: FormBuilder,
              private modalCtrl: ModalController,
              private globalData: GlobalData,
              private alertCtrl: AlertController,
              private loginService: LoginService) {
    this.setPasswordForm = this.formBuilder.group({
      password1: [, [Validators.required, Validators.minLength(6), Validators.maxLength(20)]],
      password2: [, [Validators.required, Validators.minLength(6),Validators.maxLength(20)]],
    });
    this.tel=this.globalData.userId;
    this.pwdshow="弱";
    this.pswValid=true;
  };

  onKey(pwd:string) {
    console.log(pwd);

    var m: number = 0;
    var Modes = 0;

    for (var i = 0; i < pwd.length; i++) {
      var charType = 0;
      var t = pwd.charCodeAt(i);
      if (t >= 48 && t <= 57) { charType = 1; }
      else if (t >= 65 && t <= 90) { charType = 2; }
      else if (t >= 97 && t <= 122) { charType = 4; }
      else { charType = 4; }
      Modes |= charType;
    }
    for (i = 0; i < 4; i++) {
      if (Modes & 1) { m++; }
      Modes >>>= 1;
    }

    switch (m) {
      case 1:
        this.pwdshow="弱";
        console.log("弱");
        break;
      case 2:
        this.pwdshow="中";
        console.log("中");
        break;
      case 3:
        this.pwdshow="强";
        console.log("强");
        break;
      default:
        this.pwdshow="弱";
        console.log("弱");
        break;
    }
  }





  confirm() {
    var _self=this;
   console.log(this.setPasswordForm.value.password1);
   console.log(this.setPasswordForm.value.password2);
   if(this.setPasswordForm.value.password1!=this.setPasswordForm.value.password2){
     console.log('密码不一致');
     _self.pswValid=false;
   }
   else {
     this.loginService.sendPassword(this.globalData.userPhone,this.setPasswordForm.value.password1).subscribe(res => {
       if(res.result=="yes"){
         let modal = this.modalCtrl.create(LoginPage);
         modal.present();
       }
       else {
         this.alertCtrl.create({
           title: '密码设置失败',
           subTitle: '请稍后重新设置！',
           buttons: ['确定']
         }).present();
       }
     });
   }
  }


  dismiss() {
    this.viewCtrl.dismiss();
  }






}
