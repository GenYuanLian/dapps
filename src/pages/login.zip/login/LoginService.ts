import {Injectable} from '@angular/core';
import {HttpService} from "../../providers/HttpService";
import {Observable} from "rxjs";
import {UserInfo} from "../../model/UserInfo";
import {telReturn} from "../../model/telReturn";
import {Response, Headers} from "@angular/http";
@Injectable()
export class LoginService {
  constructor(private httpService: HttpService) {
  }
  isTelRegister(tel):Observable<telReturn>{
    return this.httpService.get('http://10.103.240.171:8080/user/register/telCheck?tel='+tel).map((res: Response) => res.json());
  }
  sendVerificationCode(tel,verificationcode):Observable<telReturn>{
    return this.httpService.get('http://10.103.240.171:8080/user/register/verificationcodeCheck?tel='+tel+"&verificationcode="+verificationcode).map((res: Response) => res.json());
  }
  sendPassword(tel,pwd):Observable<telReturn>{
    return this.httpService.get('http://10.103.240.171:8080/user/register/passwordStore?tel='+tel+"&pwd="+pwd).map((res: Response) => res.json());
  }
  getObj(name):Observable<UserInfo> {
    return this.httpService.get('http://127.0.0.1:3000/users/getUserByName/'+name).map((res: Response) => res.json());
  }
  getIsRegister(user):Observable<UserInfo>{
    return this.httpService.post('http://127.0.0.1:3000/users/createUser').map((res: Response) => res.json());
  }
  register(user):Observable<UserInfo> {
    return Observable.create((observer) => {
      this.getIsRegister(user).subscribe(res =>{
        return res['success'];
      });
    });
  }

  login(tel,psw):Observable<telReturn>{
    console.log(tel);
    return this.httpService.get('http://10.103.240.255:8080/user/login?tel='+tel+"&password="+psw).map((res: Response) => res.json());
  }
  // login(user):Observable<UserInfo> {
  //   return Observable.create((observer) => {
  //     var userInfo;
  //     userInfo = {
  //       id: 1,
  //       username: 'admin',
  //       name: '902实验室',
  //       email: '123456789@126.com',
  //       phone: '13388888888',
  //       avatarId: '',
  //       description: 'bupt902程序员一枚',
  //       identification: true
  //     };
  //     observer.next(userInfo);
  //     // var userInfo;
  //     // this.getObj(user.name).subscribe(res => {
  //     //   if(res!=null){
  //     //     console.log("登陆成功");
  //     //     userInfo = {
  //     //       id: 1,
  //     //       username: res['name'],
  //     //       name: '902实验室',
  //     //       email: res['email'],
  //     //       phone: '13388888888',
  //     //       avatarId: '',
  //     //       description: 'bupt902程序员一枚',
  //     //       identification: true
  //     //     };
  //     //   }else {
  //     //     userInfo = {
  //     //       id: 1,
  //     //       username: '',
  //     //       name: '',
  //     //       email: '',
  //     //       phone: '',
  //     //       avatarId: '',
  //     //       description: '',
  //     //       identification: false
  //     //     };
  //     //   }
  //     //   observer.next(userInfo);
  //     // });
  //   });
  // }
}
