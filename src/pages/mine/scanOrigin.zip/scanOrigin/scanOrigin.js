"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Created by Luffy on 2017/5/31.
 */
var core_1 = require("@angular/core");
var ScanOriginService_1 = require("./ScanOriginService");
var goodDetail_1 = require("../goodDetail/goodDetail");
var ScanOriginPage = (function () {
    function ScanOriginPage(navCtrl, scanOriginService, navParams) {
        this.navCtrl = navCtrl;
        this.scanOriginService = scanOriginService;
        this.navParams = navParams;
        this.userName = navParams.get("userName");
        console.log(this.userName + "1111");
        this.scanOriginService.getGoodsList(13521365896).subscribe(function (res) {
            console.log(res);
        });
    }
    ScanOriginPage.prototype.goodDetail = function () {
        this.navCtrl.push(goodDetail_1.GoodDetailPage, {
            goodId: "123456"
        });
    };
    return ScanOriginPage;
}());
ScanOriginPage = __decorate([
    core_1.Component({
        selector: 'page-scanOrigin',
        templateUrl: 'scanOrigin.html',
        providers: [ScanOriginService_1.ScanOriginService]
    })
], ScanOriginPage);
exports.ScanOriginPage = ScanOriginPage;
