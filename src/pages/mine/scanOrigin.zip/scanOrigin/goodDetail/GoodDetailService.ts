/**
 * Created by Luffy on 2017/6/1.
 */
import {Injectable} from '@angular/core';
import {HttpService} from "../../../../providers/HttpService";
import {Observable} from "rxjs";
import {Response} from "@angular/http";
@Injectable()
export class GoodDetailService {
  constructor(private httpService: HttpService) {
  }
  getGoodsDetail(goodsnumber):Observable<Array<Array<Object>>>{
    return this.httpService.get('http://10.103.240.167:8080/goods/GoodsDetail?goodsnumber='+goodsnumber).map((res: Response) => res.json());
  }
}
