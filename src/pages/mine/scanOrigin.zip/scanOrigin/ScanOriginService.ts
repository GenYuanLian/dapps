/**
 * Created by Luffy on 2017/6/1.
 */
import {Injectable} from '@angular/core';
import {HttpService} from "../../../providers/HttpService";
import {Observable} from "rxjs";
import {Response} from "@angular/http";
@Injectable()
export class ScanOriginService {
  constructor(private httpService: HttpService) {
  }
  getGoodsList(username):Observable<Object>{
    return this.httpService.get('http://10.103.241.59:8080/goods/getGoodsList?user_name='+username).map((res: Response) => res.json());
  }
}
