/**
 * Created by Luffy on 2017/5/31.
 */
import {Component} from '@angular/core';
import {NavController,NavParams} from 'ionic-angular';
import {NativeService} from "../../../providers/NativeService";
import {ScanOriginService} from "./ScanOriginService";
import {GoodDetailPage} from "../goodDetail/goodDetail";


@Component({
  selector: 'page-scanOrigin',
  templateUrl: 'scanOrigin.html',
  providers:[ScanOriginService]
})
export class ScanOriginPage {
  userName: string;
  constructor(private navCtrl: NavController, private scanOriginService: ScanOriginService, private navParams: NavParams) {
    this.userName = navParams.get("userName");
    console.log(this.userName+"1111");
    this.scanOriginService.getGoodsList(13521365896).subscribe(res => {
      console.log(res);
    });
  }

  goodDetail() {
      this.navCtrl.push(GoodDetailPage,{
          goodId:"123456"
      });
  }

}


